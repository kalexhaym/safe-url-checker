# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['safe_url_checker', 'safe_url_checker.integrations']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'safe-url-checker',
    'version': '1.0.0',
    'description': '',
    'long_description': '\n# Description\nA library for checking links for security using several different integrations.\n\n# How to use:\n```\nfrom safe_url_checker import SafeUrlChecker\n\nchecker = SafeUrlChecker()\nchecker.set_integrations([\n    \'GOOGLE_SAFE_BASE\',\n    \'GOOGLE_SAFE_INTERSTITIAL\',\n    \'GOOGLE_SAFE_TRANSPARENCY\',\n    \'VIRUSTOTAL\',\n])\nchecker.set_integration_params(\'GOOGLE_SAFE_BASE\', {\n    \'API_KEY\': \'token\'\n})\nchecker.set_integration_params("VIRUSTOTAL", {\n    \'API_KEY\': \'token\'\n})\ncheck_result = checker.check(urls=[\n    \'https://google.com\',\n])\n```\n',
    'author': 'Aleksei Kovalenko',
    'author_email': 'kalexhaym@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
